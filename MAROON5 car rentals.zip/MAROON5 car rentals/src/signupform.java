
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class signupform extends javax.swing.JFrame {

    /**
     * Creates new form signupform
     */
 
    public signupform() {
        initComponents();
        jLabel12.setVisible(false);
        jRadioButton6.setVisible(false);
        jRadioButton7.setVisible(false);
        jRadioButton8.setVisible(false);
        jRadioButton9.setVisible(false);
        jLabel13.setVisible(false);
        jTextField7.setVisible(false);
        String a = "MAROON5’S RESPONSIBILITIES INCLUDE:\n" +
"•	Booking a valid cab and issuing a valid ticket (a ticket that will be accepted by the Taxi or Auto-Rickshaw operator) for it's network\n" +
"•	Providing refund and support in the event of cancellation. If any customers pays the booking money (in advance) and cancels the trip before 45 minutes of booking then the refund will be made in online mode to customers within 8-10 business days.\n" +
"•	Providing customer support and information in case of any delays / inconvenience\n" +
"MAROON5’S RESPONSIBILITIES DO NOT INCLUDE:\n" +
"•	The Taxi operator’s not departing / reaching on time.\n" +
"•	The Taxi employees being rude.\n" +
"•	The Taxi operator’s seats etc. not being up to the customer’s expectation.\n" +
"•	The Taxi operator canceling the trip due to unavoidable reasons.\n" +
"•	The baggage of the customer getting lost / stolen / damaged.\n" +
"•	The Taxi operator chooses a long route\n" +
"•	The Taxi operator changing a booked cab at the last minute.\n" +
"•	The customer waiting at the wrong boarding point (please call the Taxi Driver to find out the exact boarding point if you are not a regular traveler)\n" +
"•	The Taxi operator changing the boarding point and/or using a pick-up vehicle at the boarding point to take customers to the Taxi departure point.\n" +
"QUOTES AND PAYMENT\n" +
"The customer shall pay the sum of the following:\n" +
"\n" +
"The fare as per taxi meter or as per fixed fare agreed, whichever applicable,\n" +
"\n" +
"The toll charges will be payable by customer as applicable, only when crossing the toll post,\n" +
"\n" +
"Parking charges (where applicable),\n" +
"\n" +
"Additional night surcharge (where applicable) and\n" +
"\n" +
"Any fee or levy presently payable or hereinafter imposed by the law or required to be paid for availing of the taxi services.\n" +
"VARIATIONS\n" +
"The Customer agrees and acknowledges that the use of the services offered by Maroon5 app is at the sole risk of the Customer and that Maroon5 app disclaims all representations and warranties of any kind, whether express or implied as to condition, suitability, quality, merchantability and fitness for any purposes are excluded to the fullest extent permitted by law.\n" +
"\n" +
"Without prejudice to the above, Maroon5 app makes no representation or warranty that:\n" +
"\n" +
"the service will meet your requirements,\n" +
"\n" +
"the service will be uninterrupted, timely, secure, or error-free.\n" +
"\n" +
"Maroon5 app shall be entitled to add to, vary or amend any or all these terms and conditions at any time and the Customer shall be bound by such addition, variation or amendment once such addition, variation or amendment are incorporated into these terms and conditions at www.Maroon5.com or on the date that Maroon5 app may indicate that such addition, variation or amendment is to come into effect.\n" +
"LIABILITY\n" +
"Maroon5 app shall not be responsible or liable for any loss or damage, howsoever caused or suffered by the Customer arising out of the use of taxi service offered by Maroon5 app or due to the failure of Maroon5 app to provide services to the Customer for any reason whatsoever including but not limited to the Customer's non-compliance with the services' recorded voice instructions, malfunction, partial or total failure of any network terminal, data processing system, computer tele-transmission or telecommunications system or other circumstances whether or not beyond the control of Maroon5 app or any person or any organization involved in the above mentioned systems.\n" +
"\n" +
"Without prejudice to the above, Maroon5 app shall not be liable for any direct or indirect loss or damage which may be suffered by the Customer as a result of any failure by Maroon5 app to provide a taxi to the Customer within any stipulated time even if Maroon5 app has agreed to so provide the taxi or even if the Customer has advised Maroon5 app of the possibility that any such loss or damage would result if the taxi is not provided at all or within the stipulated time.\n" +
"\n" +
"Customer shall indemnify Maroon5 app from and against and in respect of any or all liabilities, losses, charges and expenses (including legal fees and costs on a full indemnify basis) claims, demands, actions and proceedings which Maroon5 app may incur or sustain directly or indirectly from or by any reason of or in relation to the use or purposed use of the Services by the Customer and shall pay such sums on demand.\n" +
"GENERAL\n" +
"All the calls made to our call centre are recorded by us for quality and training purposes.\n" +
"\n" +
"All vehicles registered with Maroon5 app are continuously tracked using GPS for security reasons only.\n" +
"\n" +
"Maroon5 app shall be entitled at any time without giving any reason or prior notice to terminate the booking of taxis done by the Customer.\n" +
"\n" +
"Maroon5 app encourages all its customers to take full responsibility of his/her items. In case of lost items inside the Maroon5 app Cabs during the journey, Maroon5 app will try to locate the items but is not responsible for the same in case of loss or damage to the same.\n" +
"\n" +
"If the Customer leaves any goods in the taxi or has any complaint in respect of the services or the use of the taxi, the Customer has to inform Maroon5 app of the same in writing within 24hours of using the taxi or the services of Maroon5 app.\n" +
"\n" +
"For usage outside India, respective city's court shall have the sole and exclusive jurisdiction in respect of any matters arising from the use of the services offered by Maroon5 app or the agreement or arrangement between Maroon5 app and the Customer.\n" +
"\n" +
"This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.\n" +
"\n" +
"All trade marks reproduced in this website which are not the property of, or licensed to, the operator are acknowledged on the website.\n" +
"\n" +
"Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.\n" +
"\n" +
"From time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).\n" +
"\n" +
"Your use of this website and any dispute arising out of such use of the website is subject to the local laws in respective city.\n" +
"DATA PROTECTION\n" +
"Maroon5 app is hereby authorized to use the location based information provided by any of the telecommunication companies when the Customer uses the mobile phone to make a taxi booking. The location based information will be used only to facilitate and improve the probability of locating a taxi for the Customer.\n" +
"\n" +
"Maroon5 app have right to use the customer contact information for our own marketing purposes. We may send regular SMS and Email updates to the registered mobile numbers and email Ids registered with us.\n" +
"\n" +
"Maroon5 app shall be entitled to disclose to all group companies of Maroon5 app or any of its authorized chauffeurs or any government body as so required by the law or by directive or request from such government body or any third party, the particulars of the Customer in the possession of Maroon5 app in any way as Maroon5 app, in its absolute discretion, deems fit or if it considers it in its interests to do so.\n" +
"\n" +
"Maroon5 app does not warrant that this site, its servers, or e-mail sent from Maroon5 app are free of viruses or other harmful components. Maroon5 app will not be liable for any damages of any kind arising from the use of this site, including, but not limited to direct, indirect, incidental, punitive, and consequential damages.\n" +
"";
        jTextArea1.setText(a);
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel11 = new javax.swing.JLabel();
        jPasswordField2 = new javax.swing.JPasswordField();
        jCheckBox1 = new javax.swing.JCheckBox();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jRadioButton7 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jRadioButton9 = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(34, 49, 63));
        jPanel1.setForeground(new java.awt.Color(228, 241, 254));
        jPanel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(228, 241, 254));
        jLabel1.setText("Enter full name");
        jLabel1.setToolTipText("");

        jTextField1.setBackground(new java.awt.Color(34, 49, 63));
        jTextField1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(228, 241, 254));
        jTextField1.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(228, 241, 254));
        jLabel2.setText("Address(locality)");
        jLabel2.setToolTipText("");

        jTextField2.setBackground(new java.awt.Color(34, 49, 63));
        jTextField2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(228, 241, 254));
        jTextField2.setToolTipText("");

        jLabel3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(228, 241, 254));
        jLabel3.setText("Gender");
        jLabel3.setToolTipText("");

        jTextField3.setBackground(new java.awt.Color(34, 49, 63));
        jTextField3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField3.setForeground(new java.awt.Color(228, 241, 254));
        jTextField3.setToolTipText("");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton1.setText("Male");
        jRadioButton1.setToolTipText("");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton2.setText("Female");
        jRadioButton2.setToolTipText("");

        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton3.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton3.setText("Not specified");
        jRadioButton3.setToolTipText("");

        jLabel4.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(228, 241, 254));
        jLabel4.setText("Date of Birth(YYYY-MM-DD)");
        jLabel4.setToolTipText("");

        jLabel5.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(228, 241, 254));
        jLabel5.setText("Contact Number");
        jLabel5.setToolTipText("");

        jTextField4.setBackground(new java.awt.Color(34, 49, 63));
        jTextField4.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField4.setForeground(new java.awt.Color(228, 241, 254));
        jTextField4.setToolTipText("");

        jLabel6.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(228, 241, 254));
        jLabel6.setText("(+91)");
        jLabel6.setToolTipText("");

        jLabel7.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(228, 241, 254));
        jLabel7.setText("Email Id");
        jLabel7.setToolTipText("");

        jTextField5.setBackground(new java.awt.Color(34, 49, 63));
        jTextField5.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField5.setForeground(new java.awt.Color(228, 241, 254));
        jTextField5.setToolTipText("");

        jLabel8.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(228, 241, 254));
        jLabel8.setText("Create account");
        jLabel8.setToolTipText("");

        jLabel9.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(228, 241, 254));
        jLabel9.setText("Username");
        jLabel9.setToolTipText("");

        jTextField6.setBackground(new java.awt.Color(34, 49, 63));
        jTextField6.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField6.setForeground(new java.awt.Color(228, 241, 254));
        jTextField6.setToolTipText("");

        jLabel10.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(228, 241, 254));
        jLabel10.setText("Password");
        jLabel10.setToolTipText("");

        jPasswordField1.setBackground(new java.awt.Color(34, 49, 63));
        jPasswordField1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jPasswordField1.setForeground(new java.awt.Color(228, 241, 254));
        jPasswordField1.setToolTipText("");

        jLabel11.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(228, 241, 254));
        jLabel11.setText("Confirm Password");
        jLabel11.setToolTipText("");

        jPasswordField2.setBackground(new java.awt.Color(34, 49, 63));
        jPasswordField2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jPasswordField2.setForeground(new java.awt.Color(228, 241, 254));
        jPasswordField2.setToolTipText("");

        jCheckBox1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(228, 241, 254));
        jCheckBox1.setText("show password");
        jCheckBox1.setToolTipText("");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        buttonGroup2.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton4.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton4.setText("Customer");
        jRadioButton4.setToolTipText("");
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });

        buttonGroup2.add(jRadioButton5);
        jRadioButton5.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton5.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton5.setText("Driver");
        jRadioButton5.setToolTipText("");
        jRadioButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton5ActionPerformed(evt);
            }
        });

        buttonGroup3.add(jRadioButton6);
        jRadioButton6.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton6.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton6.setText("Auto");
        jRadioButton6.setToolTipText("");

        buttonGroup3.add(jRadioButton7);
        jRadioButton7.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton7.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton7.setText("Sedan");
        jRadioButton7.setToolTipText("");

        buttonGroup3.add(jRadioButton8);
        jRadioButton8.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton8.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton8.setText("Indica");
        jRadioButton8.setToolTipText("");

        buttonGroup3.add(jRadioButton9);
        jRadioButton9.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jRadioButton9.setForeground(new java.awt.Color(228, 241, 254));
        jRadioButton9.setText("Suv");
        jRadioButton9.setToolTipText("");

        jLabel12.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(228, 241, 254));
        jLabel12.setText("Choose Type of Vehicle");
        jLabel12.setToolTipText("");

        jLabel13.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(228, 241, 254));
        jLabel13.setText("Vehicle Number");
        jLabel13.setToolTipText("");

        jTextField7.setBackground(new java.awt.Color(34, 49, 63));
        jTextField7.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField7.setForeground(new java.awt.Color(228, 241, 254));
        jTextField7.setToolTipText("");

        jLabel14.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(228, 241, 254));
        jLabel14.setToolTipText("");

        jTextField8.setBackground(new java.awt.Color(34, 49, 63));
        jTextField8.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jTextField8.setForeground(new java.awt.Color(228, 241, 254));
        jTextField8.setToolTipText("");

        jCheckBox2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jCheckBox2.setForeground(new java.awt.Color(228, 241, 254));
        jCheckBox2.setText("Click to Generate Captcha");
        jCheckBox2.setToolTipText("");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jCheckBox3.setForeground(new java.awt.Color(228, 241, 254));
        jCheckBox3.setText("Accept the Terms and Conditions");
        jCheckBox3.setToolTipText("");
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        jScrollPane1.setForeground(new java.awt.Color(228, 241, 254));
        jScrollPane1.setToolTipText("");

        jTextArea1.setBackground(new java.awt.Color(34, 49, 63));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI Semilight", 0, 13)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(228, 241, 254));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setDisabledTextColor(new java.awt.Color(34, 49, 63));
        jScrollPane1.setViewportView(jTextArea1);

        jButton2.setBackground(new java.awt.Color(34, 49, 63));
        jButton2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(228, 241, 254));
        jButton2.setText("Reset");
        jButton2.setToolTipText("");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(34, 49, 63));
        jButton3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(228, 241, 254));
        jButton3.setText("Skip creating Maroon5 Money Account");
        jButton3.setToolTipText("");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(34, 49, 63));
        jButton4.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(228, 241, 254));
        jButton4.setText("Continue to Create Maroon5 Account");
        jButton4.setToolTipText("");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(228, 241, 254));
        jLabel15.setText("Welcome to Maroon5 Car Rentals");

        jButton1.setBackground(new java.awt.Color(34, 49, 63));
        jButton1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(228, 241, 254));
        jButton1.setText("Go Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel16.setBackground(new java.awt.Color(34, 49, 63));
        jLabel16.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(228, 241, 254));
        jLabel16.setText("Please enter all the Details to Create an Account");

        jLabel17.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(228, 241, 254));
        jLabel17.setText("Choose User Type");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jCheckBox2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel13)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(54, 54, 54))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jButton1)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel7)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                                    .addComponent(jLabel1)
                                                                    .addGap(18, 18, 18)
                                                                    .addComponent(jTextField1))
                                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                                    .addComponent(jLabel5)
                                                                    .addGap(18, 18, 18)
                                                                    .addComponent(jLabel6)
                                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                    .addComponent(jTextField4))
                                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                                    .addComponent(jLabel3)
                                                                    .addGap(18, 18, 18)
                                                                    .addComponent(jRadioButton1)
                                                                    .addGap(18, 18, 18)
                                                                    .addComponent(jRadioButton2)
                                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                    .addComponent(jRadioButton3)))
                                                            .addGap(177, 177, 177)
                                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                .addComponent(jLabel4)
                                                                .addComponent(jLabel2))))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jLabel9)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jLabel17)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jRadioButton4)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jRadioButton5))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(272, 272, 272)
                                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(51, 51, 51)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE)
                                                        .addComponent(jTextField3)
                                                        .addComponent(jTextField5))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(64, 64, 64)
                                                        .addComponent(jCheckBox1))))
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(342, 342, 342)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jLabel10)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(39, 39, 39)
                                                        .addComponent(jLabel11))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jLabel12)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(jRadioButton6)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jRadioButton7)))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jRadioButton8)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jRadioButton9))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(35, 35, 35)
                                                        .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jCheckBox3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jButton2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jButton3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jButton4)))
                                        .addGap(6, 6, 6))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(303, 303, 303)
                                .addComponent(jLabel16))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(373, 373, 373)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jCheckBox1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jRadioButton6)
                                    .addComponent(jRadioButton7)
                                    .addComponent(jRadioButton8)
                                    .addComponent(jRadioButton9)
                                    .addComponent(jLabel12))
                                .addGap(18, 18, 18))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jRadioButton5)
                                    .addComponent(jRadioButton4))
                                .addGap(56, 56, 56)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox2)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel13)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox3)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
        if (jCheckBox1.isSelected())
        {
            jPasswordField1.setEchoChar((char)0);
            jPasswordField2.setEchoChar((char)0); 
        }
        else 
        {
            jPasswordField1.setEchoChar('*');
            jPasswordField2.setEchoChar('*');
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jRadioButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton5ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton5.isSelected()==true)
        {
        jLabel12.setVisible(true);
        jRadioButton6.setVisible(true);
        jRadioButton7.setVisible(true);
        jRadioButton8.setVisible(true);
        jRadioButton9.setVisible(true);
        jLabel13.setVisible(true);
        jTextField7.setVisible(true);
        jButton4.setVisible(false);
        jButton3.setText("Create Account");
        }
        
        
        
    }//GEN-LAST:event_jRadioButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.hide();
        Introduction a = new Introduction();
        a.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
        int RAND = ThreadLocalRandom.current().nextInt(1000,9999); 
       if (jCheckBox2.isSelected())
           jLabel14.setText(RAND + "");
       else
       {
           jCheckBox2.setText("Click to Generate Captcha");
           jLabel14.setText("");
       }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jPasswordField1.setText("");
        jPasswordField2.setText("");
        jLabel14.setText("");
        jRadioButton1.setSelected(false);
        jRadioButton2.setSelected(false);
        jRadioButton3.setSelected(false);
        jRadioButton4.setSelected(false);
        jRadioButton5.setSelected(false);
        jRadioButton6.setSelected(false);
        jRadioButton7.setSelected(false);
        jRadioButton8.setSelected(false);
        jRadioButton9.setSelected(false);
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
        jCheckBox3.setSelected(false);
        jTextArea1.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        // TODO add your handling code here:
        jLabel12.setVisible(false);
        jRadioButton6.setVisible(false);
        jRadioButton7.setVisible(false);
        jRadioButton8.setVisible(false);
        jRadioButton9.setVisible(false);
        jLabel13.setVisible(false);
        jTextField7.setVisible(false);
        jButton4.setVisible(true);
        jButton3.setText("Skip creating Maroon5 Money Account");
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        
        String a = jLabel14.getText();
        String b = jTextField8.getText();
        if(a.equals(b) && jCheckBox3.isSelected() == true)
        {
        String name = jTextField1.getText().toUpperCase();
        String address = jTextField2.getText().toUpperCase();
          
        //to check and assign gender
        String gender;
        if(jRadioButton1.isSelected() == true)
        {
            gender = "M";
        }
        else if (jRadioButton2.isSelected() == true)
        {
            gender = "F";
        }
        else if (jRadioButton3.isSelected() == true)
        {
            gender = "N";
        }
        else{
            JOptionPane.showMessageDialog(null,"Please Choose Gender");
        return;
        }
            
        
        
        String dob = jTextField3.getText();
        String contact = jTextField4.getText().toUpperCase();
        String email = jTextField5.getText().toUpperCase();
        String username = jTextField6.getText();
        
        
        //to verify if the password entered in both fiels is correct
        String password = "";
        String c = new String(jPasswordField1.getPassword());
        String d = new String(jPasswordField2.getPassword());
        if(c.equals(d))
        {
           password =jPasswordField1.getText() ;
        }
        else if (c != d)
        {
            JOptionPane.showMessageDialog(null,"Please check if Password entered in both Fields is Same");
            return; 
        }
        
        // to check if the user is a customer or a driver
        if(jRadioButton4.isSelected() == true)
        {
        Connection con = null;
        Statement st = null;
        try{
            Class.forName("java.sql.DriverManager");
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:MySql://127.0.0.1/maroon5","root","Sql@123");
            st=con.createStatement();
            String sql = "INSERT INTO CUSTOMER VALUES('" + username + "', '" + password + "','" + name + "', '" + gender + "','" + dob + "', '" + address + "', '" + contact + "', '" + email + "');";
            int n = st.executeUpdate(sql);
            if(n>0)
            {
                JOptionPane.showMessageDialog(null, "Congratulations!  Thank you for signing up in Maroon5 Car Rentals you may now use your MAccount");
                this.hide();
                Introduction v = new Introduction();
                v.setVisible(true);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "please create unique username");
                return;
            }
            con.close();
            st.close();
        }
    
        catch (Exception e)
        {
          javax.swing.JOptionPane.showMessageDialog(null, e.getMessage());
        }
        }
        else if (jRadioButton5.isSelected() == true)
        {
            String vehicle;
          if(jRadioButton6.isSelected() == true)
          {
               vehicle = "AUTO";
          }
          else if(jRadioButton7.isSelected() == true)
          {
               vehicle = "SEDAN";
          }
          else if(jRadioButton8.isSelected() == true)
          {
               vehicle = "INDICA";
          }
          else if(jRadioButton9.isSelected() == true)
          {
               vehicle = "SUV";
          }
          else
          {
              JOptionPane.showMessageDialog(null, "please select the vehicle you own");
              return;
          }
        String vehnum = jTextField7.getText().toUpperCase();
        
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        String a1 = null;
        try{
            Class.forName("java.sql.DriverManager");
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:MySql://127.0.0.1/maroon5","root","Sql@123");
            st=con.createStatement();
            rs=st.executeQuery("SELECT COUNT(*) FROM DRIVERBANK;");
             while(rs.next())
            { 
              a1 = rs.getString("COUNT(*)");
            }
            int n = Integer.parseInt(a1);
            n=n+1;
            String sql = "INSERT INTO DRIVER VALUES('" + username + "', '" + password + "','" + name + "', '" + gender + "', '" + dob + "', '" + vehicle + "', '" + vehnum + "', '" + address + "', '" + contact + "',' " + email + "'   );";
            String sql1 = "INSERT INTO DRIVERBANK VALUES( " +n+ ", '" +username+ "', 0 );";
            st.executeUpdate(sql1);
            int m = st.executeUpdate(sql);
            if(m>0)
            {
                JOptionPane.showMessageDialog(null, "Congratulations!  Thank you for signing up in Maroon5 Car Rentals you may now use your MAccount");
                this.hide();
                Introduction m1 = new Introduction();
                m1.setVisible(true);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "please create unique username");
                return;
            }
            con.close();
            st.close();
        }
    
        catch (Exception e)
        {
          javax.swing.JOptionPane.showMessageDialog(null, e.getMessage());
        }
        }
         else
         {
          JOptionPane.showMessageDialog(null, "please select user");
         }
        }
        else if( a!=b && jCheckBox3.isSelected() == true)
        {
            JOptionPane.showMessageDialog(null, " enter correct captcha");
            return;
        }
        else if( a!=b && jCheckBox3.isSelected() == false)
        {
            JOptionPane.showMessageDialog(null , "please accept the terms and conditions & also please enter correct captcha");
            return;
        }
        else if( a==b && jCheckBox3.isSelected() == false)
        {
            JOptionPane.showMessageDialog(null , "please accept the terms and condition");
            return;
        }
       
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        String username1 = jTextField6.getText();
        String name1 =  jTextField1.getText();
        
        String a = jLabel14.getText();
        String b = jTextField8.getText();
        if(a.equals(b) && jCheckBox3.isSelected() == true)
        {
        String name = jTextField1.getText().toUpperCase();
        String address = jTextField2.getText().toUpperCase();
          
        //to check and assign gender
        String gender;
        if(jRadioButton1.isSelected() == true)
        {
            gender = "M";
        }
        else if (jRadioButton2.isSelected() == true)
        {
            gender = "F";
        }
        else if (jRadioButton3.isSelected() == true)
        {
            gender = "N";
        }
        else{
            JOptionPane.showMessageDialog(null,"please chose gender");
        return;
        }
            
        
        
        String dob = jTextField3.getText();
        String contact = jTextField4.getText().toUpperCase();
        String email = jTextField5.getText().toUpperCase();
        String username = jTextField6.getText();
        
        
        //to verify if the password entered in both fiels is correct
        String password = "";
        String c = new String(jPasswordField1.getPassword());
        String d = new String(jPasswordField2.getPassword());
        if(c.equals(d))
        {
           password =jPasswordField1.getText() ;
        }
        else if (c != d)
        {
            JOptionPane.showMessageDialog(null,"please make sure password in both fields is entered same");
            return; 
        }
        
        // to check if the user is a customer or a driver
        if(jRadioButton4.isSelected() == true)
        {
        Connection con = null;
        Statement st = null;
        
        try{
            Class.forName("java.sql.DriverManager");
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:MySql://127.0.0.1/maroon5","root","Sql@123");
            st=con.createStatement();
            String sql = "INSERT INTO CUSTOMER VALUES('" + username + "', '" + password + "','" + name + "', '" + gender + "','" + dob + "', '" + address + "', '" + contact + "', '" + email + "');";
            int n = st.executeUpdate(sql);
            if(n>0)
            {
                JOptionPane.showMessageDialog(null, "Congratulations!  Thank you for signing up in Maroon5 Car Rentals you may now use your MAccount   You are now being taken to Maroon5 Money Sign up Page");
               
            }
            else
            {
                JOptionPane.showMessageDialog(null, "please create unique username");
                return;
            }
            con.close();
            st.close();
        }
    
        catch (Exception e)
        {
          javax.swing.JOptionPane.showMessageDialog(null, e.getMessage());
        }
        }
        else if (jRadioButton5.isSelected() == true)
        {
            String vehicle;
          if(jRadioButton6.isSelected() == true)
          {
               vehicle = "AUTO";
          }
          else if(jRadioButton7.isSelected() == true)
          {
               vehicle = "SEDAN";
          }
          else if(jRadioButton8.isSelected() == true)
          {
               vehicle = "INDICA";
          }
          else if(jRadioButton9.isSelected() == true)
          {
               vehicle = "SUV";
          }
          else
          {
              JOptionPane.showMessageDialog(null, "please select the vehicle you own");
              return;
          }
        String vehnum = jTextField7.getText().toUpperCase();
        
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        String a1 = null;
        try{
            Class.forName("java.sql.DriverManager");
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:MySql://127.0.0.1/maroon5","root","Sql@123");
            st=con.createStatement();
            rs=st.executeQuery("SELECT COUNT(*) FROM DRIVERBANK;");
             while(rs.next())
            { 
              a1 = rs.getString("COUNT(*)");
            }
            int n = Integer.parseInt(a1);
            n=n+1;
            String sql1 = "INSERT INTO DRIVERBANK VALUES( " +n+ ", '" +username+ "', 0 );";
            st.executeUpdate(sql1);
            String sql = "INSERT INTO DRIVER VALUES('" + username + "', '" + password + "','" + name + "', '" + gender + "', '" + dob + "', '" + vehicle + "', '" + vehnum + "', '" + address + "', '" + contact + "',' " + email + "'   );";
            int m = st.executeUpdate(sql);
            if(m>0)
            {
                JOptionPane.showMessageDialog(null, "congratulation! and thank you for signing up in Maroon5 you may now use your account");
                
            }
            else
            {
                JOptionPane.showMessageDialog(null, "please create unique username");
                return;
            }
            con.close();
            st.close();
        }
    
        catch (Exception e)
        {
          javax.swing.JOptionPane.showMessageDialog(null, e.getMessage());
        }
        }
         else
         {
          JOptionPane.showMessageDialog(null, "please select user");
         }
        }
        else if( a!=b && jCheckBox3.isSelected() == true)
        {
            JOptionPane.showMessageDialog(null, " enter correct captcha");
            return;
        }
        else if( a!=b && jCheckBox3.isSelected() == false)
        {
            JOptionPane.showMessageDialog(null , "please accept the terms and conditions and also please enter correct captcha");
            return;
        }
        else if( a==b && jCheckBox3.isSelected() == false)
        {
            JOptionPane.showMessageDialog(null , "please accept the terms and condition");
            return;
        }
        
        maroon5money m = new maroon5money();
        m.jLabel1.setText(username1);
        this.hide();
        m.setVisible(true);
       
        
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(signupform.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(signupform.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(signupform.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(signupform.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new signupform().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JRadioButton jRadioButton9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables
}
